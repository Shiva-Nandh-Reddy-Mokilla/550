package com.tr_reny.freqflier;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity2 extends AppCompatActivity {

    String cid = "";
    //Declarations
    private Button btn_flight_detais, btn_all_flights, btn_redemption_info, btn_transfer_points, btn_exit;
    private ImageView imageView;
    private TextView tv_name, tv_points;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intent = getIntent();
        cid = intent.getStringExtra("cid");

        btn_flight_detais = findViewById(R.id.btn_flight_details);
        btn_all_flights = findViewById(R.id.btn_all_flights);
        btn_redemption_info = findViewById(R.id.btn_redemtion_info);
        btn_transfer_points = findViewById(R.id.btn_transfer_points);
        btn_exit = findViewById(R.id.btn_exit);
        imageView = findViewById(R.id.imageView);
        tv_name = findViewById(R.id.tv_name);
        tv_points = findViewById(R.id.tv_points);
        RequestQueue queue = Volley.newRequestQueue(this);


        String url = "http://127.0.0.1:8080/frequentflier/Info.jsp?cid=" + cid;

        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                String[] result = s.trim().split(",");
                String name = result[0];
                String points = result[1];
                tv_name.setText(name);
                tv_points.setText(points);
            }
        }, null);
        queue.add(request);


        String url2 = "http://127.0.0.1:8080/frequentflier/images/" + cid + ".png";
        ImageRequest request2 = new ImageRequest(url2, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap bitmap) {
                imageView.setImageBitmap(bitmap);
            }
        }, 0, 0, null, null);
        queue.add(request2);


        //Buttons ClickListeners
        btn_flight_detais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this, MainActivity4.class);
                startActivity(intent);

            }
        });

        btn_all_flights.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                startActivity(intent);

            }
        });

        btn_redemption_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this, MainActivity5.class);
                startActivity(intent);

            }
        });

        btn_transfer_points.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this, MainActivity6.class);
                startActivity(intent);

            }
        });

        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(0);
            }
        });


    }
}