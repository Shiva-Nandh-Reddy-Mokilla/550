package com.tr_reny.freqflier;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity3 extends AppCompatActivity {

    Intent intent = getIntent();


    //Declaration

    private TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        RequestQueue queue = Volley.newRequestQueue(this);
        //findviews
        textView = findViewById(R.id.textView_flights);


        String url1 = "http://127.0.0.1:8080/frequentflier/Flights.jsp?cid=1";
        StringRequest request1 = new StringRequest(Request.Method.GET, url1, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                String[] result = s.trim().split(",");
                String Flight_Id = result[0];
                String Flight_Miles = result[1];
                String Destination = result[2];
                String Total = result[3];
                textView.setText("\t\t\t\t" + Flight_Id + "\t\t\t\t" + Flight_Miles + "\t\t\t\t\t\t" + Destination);

            }
        }, null);
        queue.add(request1);

    }
}