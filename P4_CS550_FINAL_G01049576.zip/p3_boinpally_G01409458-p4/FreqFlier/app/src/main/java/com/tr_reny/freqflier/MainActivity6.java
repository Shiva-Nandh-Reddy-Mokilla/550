package com.tr_reny.freqflier;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity6 extends AppCompatActivity {

    String cid = "";
    String tref = "";
    String passangerId = "";
    String npoints = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        Spinner spinner = findViewById(R.id.spinner2);
        Button button7 = findViewById(R.id.button7);
    }
}