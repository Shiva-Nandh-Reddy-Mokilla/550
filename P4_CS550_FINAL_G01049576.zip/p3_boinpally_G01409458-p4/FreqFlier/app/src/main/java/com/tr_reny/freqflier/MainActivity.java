package com.tr_reny.freqflier;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    String cid = "";
    private Button btn_login;
    private EditText et_username, et_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_login = findViewById(R.id.btn_login);
        et_username = findViewById(R.id.editTextUserName);
        et_password = findViewById(R.id.editTextPassword);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*Todo only available on Testing button for UI- dlt it while testing */
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);


              /*  RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                String username = et_username.getText().toString();
                String password = et_password.getText().toString();

                String url = "http://127.0.0.1:8080/frequentflier/login?user=" + username + "&pass=" + password;
                StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                        if (s.trim().equals("No")) {
                            Toast.makeText(MainActivity.this, "Invalid Username or Password", Toast.LENGTH_LONG).show();
                        } else {
                            String[] result = s.trim().split(":");
                            cid = result[1];
                            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                            intent.putExtra("cid", cid);
                            startActivity(intent);
                        }

                    }
                }, null);
                queue.add(request);*/
            }
        });
    }
}